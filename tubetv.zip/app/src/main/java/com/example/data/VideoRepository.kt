package com.example.data

import kotlinx.coroutines.flow.Flow

class VideoRepository(private val videoDao: VideoDao) {
    val favorites: Flow<List<FavoriteVideo>> = videoDao.getFavorites()
    val recents: Flow<List<RecentVideo>> = videoDao.getRecents()

    suspend fun addFavorite(video: FavoriteVideo) {
        videoDao.addFavorite(video)
    }

    suspend fun removeFavorite(videoId: String) {
        videoDao.removeFavorite(videoId)
    }

    suspend fun addRecent(video: RecentVideo) {
        videoDao.addRecent(video)
    }

    suspend fun clearRecents() {
        videoDao.clearRecents()
    }
}
