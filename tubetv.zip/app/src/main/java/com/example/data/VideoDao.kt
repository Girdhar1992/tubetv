package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM favorites")
    fun getFavorites(): Flow<List<FavoriteVideo>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(video: FavoriteVideo)

    @Query("DELETE FROM favorites WHERE videoId = :videoId")
    suspend fun removeFavorite(videoId: String)

    @Query("SELECT * FROM recents ORDER BY timestamp DESC LIMIT 20")
    fun getRecents(): Flow<List<RecentVideo>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addRecent(video: RecentVideo)

    @Query("DELETE FROM recents")
    suspend fun clearRecents()
}
