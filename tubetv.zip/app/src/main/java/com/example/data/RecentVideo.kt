package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recents")
data class RecentVideo(
    @PrimaryKey val videoId: String,
    val title: String,
    val thumbnailUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)
