package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteVideo(
    @PrimaryKey val videoId: String,
    val title: String,
    val thumbnailUrl: String
)
