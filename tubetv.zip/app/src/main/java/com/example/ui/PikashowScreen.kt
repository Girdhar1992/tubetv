package com.example.ui

import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.tv.material3.*

data class PikashowMirror(
    val name: String,
    val url: String,
    val description: String
)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun PikashowScreen(
    isDark: Boolean,
    onBackToHome: () -> Unit
) {
    val mirrors = remember {
        listOf(
            PikashowMirror("PikaShow TV Mirror 1", "https://pikashowtv.in", "Main server for movies, live sports & series"),
            PikashowMirror("PikaShow Video Mirror 2", "https://pikashows.video", "High speed alternative movie server"),
            PikashowMirror("PikaShow Lat Mirror 3", "https://pikashow.lat", "Premium mirror with daily show updates"),
            PikashowMirror("PikaShow Pro Mirror 4", "https://pikashowpro.app", "Backup proxy server for streaming channels")
        )
    }

    var selectedMirrorUrl by remember { mutableStateOf<String?>(null) }
    var customUrlInput by remember { mutableStateOf("") }
    var activeUrlToLoad by remember { mutableStateOf<String?>(null) }

    val textColor = if (isDark) Color.White else Color(0xFF1D1B20)
    val cardBg = if (isDark) Color(0xFF323035) else Color(0xFFEADDFF)
    val brandRed = Color(0xFFE50914) // Pikashow / Netflix Red Theme accent

    if (activeUrlToLoad != null) {
        // Hardware accelerated streaming playback inside safe TV container
        Box(modifier = Modifier.fillMaxSize()) {
            var webViewInstance by remember { mutableStateOf<WebView?>(null) }

            // Safe TV back key navigation intercept
            BackHandler(enabled = true) {
                val webView = webViewInstance
                if (webView != null && webView.canGoBack()) {
                    webView.goBack()
                } else {
                    activeUrlToLoad = null // Exit back to list
                }
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // TV Player HUD Control Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { activeUrlToLoad = null },
                        colors = ButtonDefaults.colors(
                            containerColor = brandRed,
                            contentColor = Color.White
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Back to Mirrors / मिरर सूची", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Streaming: $activeUrlToLoad",
                        color = textColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )

                    Button(
                        onClick = {
                            webViewInstance?.reload()
                        },
                        colors = ButtonDefaults.colors(
                            containerColor = if (isDark) Color(0xFF323035) else Color(0xFFEADDFF),
                            contentColor = textColor
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reload",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reload / फिर से लोड करें", fontSize = 11.sp)
                        }
                    }
                }

                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    factory = { context ->
                        WebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                // Clean, responsive TV-friendly streaming User Agent
                                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                            }
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                    return false // Direct secure streaming inside app
                                }
                            }
                            webChromeClient = WebChromeClient()
                            loadUrl(activeUrlToLoad!!)
                            webViewInstance = this
                        }
                    },
                    update = {
                        // Maintain instance state
                    }
                )
            }
        }
    } else {
        // Mirrors listing & TV configuration panel
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "PikaShow Live TV & Movies / पिकाशॉ लाइव टीवी और फिल्में",
                            color = textColor,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Stream web series, movies and live entertainment channels / मुफ्त फिल्में व लाइव टीवी चलाएं",
                            color = textColor.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(brandRed, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "PIKASHOW STREAM",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Dual Language TV Guide Card
            item {
                Card(
                    onClick = {},
                    colors = CardDefaults.colors(
                        containerColor = if (isDark) Color(0xFF232126) else Color(0xFFF3EDF7)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "💡 TV Remote Guide / पिकाशॉ रिमोट मार्गदर्शिका",
                            color = brandRed,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• Choose any of the active PikaShow servers below to start streaming immediately.\n" +
                                    "• Use your TV remote arrow keys (D-pad) to browse channels, series, and live play.\n" +
                                    "• If any streaming channel fails to play or loads slow, switch to a different mirror server.\n" +
                                    "• Press 'Back' on your remote to exit the streaming view and return to this list.",
                            color = textColor.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            item {
                Text(
                    text = "Select PikaShow Server / पिकाशॉ सर्वर चुनें:",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Column(
                    modifier = Modifier.focusGroup(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    mirrors.forEach { mirror ->
                        var isFocused by remember { mutableStateOf(false) }
                        val borderModifier = if (isFocused) {
                            Modifier.border(3.dp, brandRed, RoundedCornerShape(16.dp))
                        } else {
                            Modifier
                        }

                        Card(
                            onClick = { activeUrlToLoad = mirror.url },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .onFocusChanged { isFocused = it.isFocused }
                                .then(borderModifier),
                            colors = CardDefaults.colors(
                                containerColor = cardBg
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 20.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(brandRed.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "PikaShow Stream",
                                            tint = brandRed,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(
                                            text = mirror.name,
                                            color = if (isFocused && !isDark) Color(0xFF1D1B20) else textColor,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = mirror.description,
                                            color = if (isFocused && !isDark) Color(0xFF49454F) else textColor.copy(alpha = 0.65f),
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .background(brandRed, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "STREAM / चलाएं",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Load Custom PikaShow Mirror / अन्य लिंक दर्ज करें:",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = customUrlInput,
                        onValueChange = { customUrlInput = it },
                        placeholder = { Text("https://example-pikashow-url.com") },
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = if (isDark) Color(0xFF323035) else Color(0xFFE8DEF8),
                            unfocusedContainerColor = if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7),
                            focusedTextColor = textColor,
                            unfocusedTextColor = textColor
                        )
                    )

                    Button(
                        onClick = {
                            val cleanUrl = customUrlInput.trim()
                            if (cleanUrl.isNotEmpty()) {
                                val urlWithProtocol = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                                    "https://$cleanUrl"
                                } else {
                                    cleanUrl
                                }
                                activeUrlToLoad = urlWithProtocol
                            }
                        },
                        colors = ButtonDefaults.colors(
                            containerColor = brandRed,
                            contentColor = Color.White
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Go",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("GO / चलाएं", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
