package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PurplePrimary = Color(0xFF6750A4)
val RedSecondary = Color(0xFFBA1A1A)
val LavenderTertiary = Color(0xFFD0BCFF)
val BackgroundLight = Color(0xFFFEF7FF)
val OnBackgroundDark = Color(0xFF1D1B20)
val SurfaceVariant = Color(0xFFE8DEF8)
