package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AppSettings(
    val isDarkTheme: Boolean = true,
    val isAutoplayEnabled: Boolean = true,
    val fontScale: Float = 1.0f,
    val parentalPin: String = "" // Empty means PIN not set/disabled
)

class TVViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java, "tubetv-db"
    ).fallbackToDestructiveMigration().build()

    private val repository = VideoRepository(db.videoDao())

    // UI States
    val favorites = repository.favorites.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val recents = repository.recents.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Parental PIN verification state
    private val _isSettingsLocked = MutableStateFlow(false)
    val isSettingsLocked: StateFlow<Boolean> = _isSettingsLocked.asStateFlow()

    init {
        // Load settings from SharedPreferences
        val sp = application.getSharedPreferences("tubetv_prefs", Application.MODE_PRIVATE)
        _settings.value = AppSettings(
            isDarkTheme = sp.getBoolean("dark_theme", true),
            isAutoplayEnabled = sp.getBoolean("autoplay", true),
            fontScale = sp.getFloat("font_scale", 1.0f),
            parentalPin = sp.getString("parental_pin", "") ?: ""
        )
        // Set initial lock state if a PIN is set
        _isSettingsLocked.value = _settings.value.parentalPin.isNotEmpty()
    }

    // Video Feed Data
    val allVideos = listOf(
        VideoItem("9mX0aX0SjRE", "4K Scenic Nature & Ambient Sound", "Gaming"),
        VideoItem("jfKfPfyJRdk", "Lofi Girl - Relaxing Beats", "Music"),
        VideoItem("4xDzrJKXOOY", "Synthwave Radio: Retro/Chill", "Music"),
        VideoItem("hTWKbfoikeg", "Jazz Music for Studying & Focus", "Music"),
        VideoItem("P9C25Un7xaM", "NASA Live Space Station Feed", "News"),
        VideoItem("2a_HCNp_e_Y", "SpaceX Starship Launch Replay", "News"),
        VideoItem("bT_Yp_B3R8E", "National Geographic Wildlife Special", "News"),
        VideoItem("yvP6h24oIuY", "Tokyo Night Walk - Ultra HD 60fps", "Gaming"),
        VideoItem("Y382m_M17C0", "Swiss Alps Drone Flythrough 4K", "Gaming")
    )

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Favorites Interaction
    fun toggleFavorite(video: VideoItem) {
        viewModelScope.launch {
            val list = favorites.value
            val exists = list.any { it.videoId == video.id }
            if (exists) {
                repository.removeFavorite(video.id)
            } else {
                repository.addFavorite(FavoriteVideo(video.id, video.title, ""))
            }
        }
    }

    // Recents Interaction
    fun addToRecents(videoId: String, title: String) {
        viewModelScope.launch {
            repository.addRecent(RecentVideo(videoId, title, ""))
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearRecents()
        }
    }

    // Settings Modification
    fun updateTheme(isDark: Boolean) {
        _settings.value = _settings.value.copy(isDarkTheme = isDark)
        val sp = getApplication<Application>().getSharedPreferences("tubetv_prefs", Application.MODE_PRIVATE)
        sp.edit().putBoolean("dark_theme", isDark).apply()
    }

    fun updateAutoplay(enabled: Boolean) {
        _settings.value = _settings.value.copy(isAutoplayEnabled = enabled)
        val sp = getApplication<Application>().getSharedPreferences("tubetv_prefs", Application.MODE_PRIVATE)
        sp.edit().putBoolean("autoplay", enabled).apply()
    }

    fun updateFontScale(scale: Float) {
        _settings.value = _settings.value.copy(fontScale = scale)
        val sp = getApplication<Application>().getSharedPreferences("tubetv_prefs", Application.MODE_PRIVATE)
        sp.edit().putFloat("font_scale", scale).apply()
    }

    fun setParentalPin(pin: String) {
        _settings.value = _settings.value.copy(parentalPin = pin)
        val sp = getApplication<Application>().getSharedPreferences("tubetv_prefs", Application.MODE_PRIVATE)
        sp.edit().putString("parental_pin", pin).apply()
        _isSettingsLocked.value = pin.isNotEmpty()
    }

    fun unlockSettings(pin: String): Boolean {
        if (_settings.value.parentalPin == pin) {
            _isSettingsLocked.value = false
            return true
        }
        return false
    }

    fun lockSettings() {
        if (_settings.value.parentalPin.isNotEmpty()) {
            _isSettingsLocked.value = true
        }
    }

    // Utility parser to extract Video ID from URL safely
    fun extractVideoId(url: String): String? {
        if (url.isBlank()) return null
        val clean = url.trim()
        val regex = "v=([a-zA-Z0-9_-]{11})|/embed/([a-zA-Z0-9_-]{11})|/youtu\\.be/([a-zA-Z0-9_-]{11})|/v/([a-zA-Z0-9_-]{11})|/shorts/([a-zA-Z0-9_-]{11})".toRegex()
        val matchResult = regex.find(clean)
        val found = matchResult?.groupValues?.drop(1)?.firstOrNull { it.isNotEmpty() }
        if (found != null && found.length == 11) {
            return found
        }
        if (clean.length == 11 && clean.all { it.isLetterOrDigit() || it == '-' || it == '_' }) {
            return clean
        }
        return null
    }
}
