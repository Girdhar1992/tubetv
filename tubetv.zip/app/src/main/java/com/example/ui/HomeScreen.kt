package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.tv.material3.*
import com.example.data.FavoriteVideo
import com.example.data.RecentVideo

// Represent navigation items
enum class NavigationScreen(val titleEn: String, val titleHi: String, val icon: ImageVector) {
    HOME("Home", "मुख्य पृष्ठ", Icons.Default.Home),
    BROWSE("YouTube Web", "यूट्यूब ब्राउज़", Icons.Default.PlayArrow),
    NETMIRROR("Netmirror App", "नेटमिरर स्ट्रीम", Icons.Default.PlayArrow),
    PIKASHOW("PikaShow App", "पिकाशॉ स्ट्रीम", Icons.Default.Star),
    SEARCH("Search", "खोजें", Icons.Default.Search),
    FAVORITES("Favorites", "पसंदीदा", Icons.Default.Favorite),
    SETTINGS("Settings", "सेटिंग्स", Icons.Default.Settings),
    ABOUT("About & Legal", "कानूनी जानकारी", Icons.Default.Info)
}

data class VideoItem(val id: String, val title: String, val category: String)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TVViewModel,
    onVideoSelected: (String, String) -> Unit,
    onNavigateToWeb: (String) -> Unit
) {
    var currentScreen by remember { mutableStateOf(NavigationScreen.HOME) }
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val recents by viewModel.recents.collectAsStateWithLifecycle()

    // PIN lock overlay states
    var pinToVerify by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    val isLocked by viewModel.isSettingsLocked.collectAsStateWithLifecycle()
    var pendingScreenAfterUnlock by remember { mutableStateOf<NavigationScreen?>(null) }

    val bgGradient = if (settings.isDarkTheme) {
        Brush.verticalGradient(listOf(Color(0xFF1D1B20), Color(0xFF0F0E11)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFFEF7FF), Color(0xFFF3EDF7)))
    }

    val textColor = if (settings.isDarkTheme) Color.White else Color(0xFF1D1B20)
    val mutedTextColor = if (settings.isDarkTheme) Color(0xFFCAC4D0) else Color(0xFF49454F)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgGradient)
    ) {
        // If locked and trying to access Favorites/Settings, show PIN overlay
        if (isLocked && (currentScreen == NavigationScreen.SETTINGS || currentScreen == NavigationScreen.FAVORITES)) {
            PinLockScreen(
                pinValue = pinToVerify,
                onPinValueChange = { pinToVerify = it },
                onVerify = {
                    if (viewModel.unlockSettings(pinToVerify)) {
                        pinToVerify = ""
                        pinError = false
                        pendingScreenAfterUnlock?.let { currentScreen = it }
                    } else {
                        pinError = true
                        pinToVerify = ""
                    }
                },
                onCancel = {
                    currentScreen = NavigationScreen.HOME
                    pinToVerify = ""
                    pinError = false
                },
                isError = pinError,
                isDark = settings.isDarkTheme
            )
        } else {
            Row(modifier = Modifier.fillMaxSize()) {
                // COLLAPSIBLE TV NAVIGATION SIDEBAR (YouTube TV-like)
                SidebarNavigation(
                    selectedScreen = currentScreen,
                    onScreenSelected = { screen ->
                        if (screen == NavigationScreen.SETTINGS || screen == NavigationScreen.FAVORITES) {
                            if (settings.parentalPin.isNotEmpty()) {
                                pendingScreenAfterUnlock = screen
                                viewModel.lockSettings()
                            } else {
                                currentScreen = screen
                            }
                        } else {
                            currentScreen = screen
                        }
                    },
                    isDark = settings.isDarkTheme
                )

                // MAIN CONTENT PANEL
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .padding(horizontal = 32.dp, vertical = 24.dp)
                ) {
                    when (currentScreen) {
                        NavigationScreen.HOME -> HomeContent(
                            viewModel = viewModel,
                            favorites = favorites,
                            recents = recents,
                            onVideoSelected = onVideoSelected,
                            isDark = settings.isDarkTheme
                        )
                        NavigationScreen.BROWSE -> {
                            Box(modifier = Modifier.fillMaxSize()) {
                                YouTubeWebView(
                                    initialUrl = "https://m.youtube.com",
                                    modifier = Modifier.fillMaxSize(),
                                    onExit = {
                                        currentScreen = NavigationScreen.HOME
                                    }
                                )
                            }
                        }
                        NavigationScreen.NETMIRROR -> {
                            Box(modifier = Modifier.fillMaxSize()) {
                                NetmirrorScreen(
                                    isDark = settings.isDarkTheme,
                                    onBackToHome = {
                                        currentScreen = NavigationScreen.HOME
                                    }
                                )
                            }
                        }
                        NavigationScreen.PIKASHOW -> {
                            Box(modifier = Modifier.fillMaxSize()) {
                                PikashowScreen(
                                    isDark = settings.isDarkTheme,
                                    onBackToHome = {
                                        currentScreen = NavigationScreen.HOME
                                    }
                                )
                            }
                        }
                        NavigationScreen.SEARCH -> SearchContent(
                            viewModel = viewModel,
                            onVideoSelected = onVideoSelected,
                            onNavigateToWeb = onNavigateToWeb,
                            isDark = settings.isDarkTheme
                        )
                        NavigationScreen.FAVORITES -> FavoritesContent(
                            favorites = favorites,
                            onVideoSelected = onVideoSelected,
                            isDark = settings.isDarkTheme
                        )
                        NavigationScreen.SETTINGS -> SettingsContent(
                            viewModel = viewModel,
                            settings = settings,
                            isDark = settings.isDarkTheme
                        )
                        NavigationScreen.ABOUT -> AboutContent(
                            isDark = settings.isDarkTheme
                        )
                    }
                }
            }
        }
    }
}

// Side navigation component built for D-pad first focus handling
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun SidebarNavigation(
    selectedScreen: NavigationScreen,
    onScreenSelected: (NavigationScreen) -> Unit,
    isDark: Boolean
) {
    var isExpanded by remember { mutableStateOf(false) }
    val sidebarBg = if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7)
    val dividerColor = if (isDark) Color(0xFF323035) else Color(0xFFE6E1E5)

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(if (isExpanded) 220.dp else 80.dp)
            .background(sidebarBg)
            .onFocusChanged { isExpanded = it.hasFocus }
            .padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Identity Brand Icon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFFBA1A1A), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "TubeTV Play",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
            if (isExpanded) {
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "TubeTV",
                    color = if (isDark) Color.White else Color(0xFF1D1B20),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Navigation Items
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .focusGroup(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NavigationScreen.values().forEach { screen ->
                val isSelected = selectedScreen == screen
                var isFocused by remember { mutableStateOf(false) }

                val itemBg = when {
                    isFocused -> if (isDark) Color(0xFF6750A4) else Color(0xFFE8DEF8)
                    isSelected -> if (isDark) Color(0xFF323035) else Color(0xFFEADDFF)
                    else -> Color.Transparent
                }

                val itemContentColor = when {
                    isFocused -> if (isDark) Color.White else Color(0xFF1D1B20)
                    isSelected -> Color(0xFFBA1A1A)
                    else -> if (isDark) Color(0xFFCAC4D0) else Color(0xFF49454F)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(itemBg)
                        .onFocusChanged { isFocused = it.isFocused }
                        .focusable()
                        .onFocusChanged { if (it.isFocused) onScreenSelected(screen) },
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = if (isExpanded) Arrangement.Start else Arrangement.Center
                    ) {
                        Icon(
                            imageVector = screen.icon,
                            contentDescription = screen.titleEn,
                            tint = itemContentColor,
                            modifier = Modifier.size(24.dp)
                        )
                        if (isExpanded) {
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = screen.titleEn,
                                    color = itemContentColor,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = screen.titleHi,
                                    color = itemContentColor.copy(alpha = 0.7f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// HOME SCREEN MODULE WITH CATEGORIES AND HORIZONTAL ROWS
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun HomeContent(
    viewModel: TVViewModel,
    favorites: List<FavoriteVideo>,
    recents: List<RecentVideo>,
    onVideoSelected: (String, String) -> Unit,
    isDark: Boolean
) {
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val allVideos = viewModel.allVideos

    val filteredVideos = if (selectedCategory == "All") {
        allVideos
    } else {
        allVideos.filter { it.category == selectedCategory }
    }

    val categories = listOf("All", "Gaming", "Music", "News")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(28.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Live Featured Hero Banner
        item {
            FeaturedHeroBanner(
                title = "Earth from Orbit: Live Space Stream",
                titleHi = "पृथ्वी की लाइव कक्षा - अंतरिक्ष स्ट्रीम",
                description = "Official NASA stream viewing Earth live from the International Space Station (ISS).",
                onPlayClick = { onVideoSelected("P9C25Un7xaM", "Earth from Orbit: Live Space Stream") },
                isDark = isDark
            )
        }

        // Category Filter Menu
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Explore Categories / श्रेणियाँ",
                    color = if (isDark) Color.White else Color(0xFF1D1B20),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.focusGroup()
                ) {
                    items(categories) { category ->
                        val isSelected = selectedCategory == category
                        var isFocused by remember { mutableStateOf(false) }

                        val chipBg = when {
                            isFocused -> if (isDark) Color(0xFFBA1A1A) else Color(0xFFD0BCFF)
                            isSelected -> if (isDark) Color(0xFF6750A4) else Color(0xFFEADDFF)
                            else -> if (isDark) Color(0xFF323035) else Color(0xFFE8DEF8)
                        }

                        val chipTextCol = if (isFocused) Color.White else (if (isDark) Color.White else Color(0xFF1D1B20))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(chipBg)
                                .onFocusChanged { isFocused = it.isFocused }
                                .focusable()
                                .onFocusChanged { if (it.isFocused) viewModel.setCategory(category) }
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = category,
                                color = chipTextCol,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Shelf 1: Filtered Videos
        item {
            VideoShelf(
                title = if (selectedCategory == "All") "Trending Now / ट्रेंडिंग" else "$selectedCategory Playlist",
                videos = filteredVideos.map { VideoItem(it.id, it.title, it.category) },
                onVideoClick = onVideoSelected,
                isDark = isDark
            )
        }

        // Shelf 2: Recently Watched (If any exist)
        if (recents.isNotEmpty()) {
            item {
                VideoShelf(
                    title = "Recently Watched / हाल ही में देखा गया",
                    videos = recents.map { VideoItem(it.videoId, it.title, "Recent") },
                    onVideoClick = onVideoSelected,
                    isDark = isDark
                )
            }
        }

        // Shelf 3: Favorites (If any exist)
        if (favorites.isNotEmpty()) {
            item {
                VideoShelf(
                    title = "My Favorites / मेरे पसंदीदा",
                    videos = favorites.map { VideoItem(it.videoId, it.title, "Favorite") },
                    onVideoClick = onVideoSelected,
                    isDark = isDark
                )
            }
        }
    }
}

// Hero banner rendering live/featured video
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun FeaturedHeroBanner(
    title: String,
    titleHi: String,
    description: String,
    onPlayClick: () -> Unit,
    isDark: Boolean
) {
    var isFocused by remember { mutableStateOf(false) }

    val borderModifier = if (isFocused) {
        Modifier.border(3.dp, Color(0xFFBA1A1A), RoundedCornerShape(20.dp))
    } else {
        Modifier
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFFBA1A1A).copy(alpha = 0.85f),
                        Color(0xFF6750A4).copy(alpha = 0.6f)
                    )
                )
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .onFocusChanged { if (it.isFocused) { /* Can bind interaction */ } }
            .then(borderModifier)
            .shadow(12.dp, RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(Color.White, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LIVE",
                        color = Color(0xFFBA1A1A),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "FEATURED PRESENTS",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = titleHi,
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(500.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onPlayClick,
                colors = ButtonDefaults.colors(
                    containerColor = Color.White,
                    contentColor = Color(0xFFBA1A1A)
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color(0xFFBA1A1A),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Watch Now / अभी देखें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

// Reusable horizontal video shelves
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun VideoShelf(
    title: String,
    videos: List<VideoItem>,
    onVideoClick: (String, String) -> Unit,
    isDark: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = title,
            color = if (isDark) Color.White else Color(0xFF1D1B20),
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.focusGroup()
        ) {
            items(videos) { video ->
                var isFocused by remember { mutableStateOf(false) }

                val borderModifier = if (isFocused) {
                    Modifier.border(3.dp, Color(0xFFBA1A1A), RoundedCornerShape(16.dp))
                } else {
                    Modifier
                }

                val cardBg = if (isDark) Color(0xFF323035) else Color(0xFFEADDFF)
                val cardTextColor = if (isDark) Color.White else Color(0xFF1D1B20)

                Card(
                    onClick = { onVideoClick(video.id, video.title) },
                    modifier = Modifier
                        .width(220.dp)
                        .height(140.dp)
                        .onFocusChanged { isFocused = it.isFocused }
                        .then(borderModifier),
                    colors = CardDefaults.colors(
                        containerColor = cardBg
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Brand Badge
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFBA1A1A).copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = video.category.uppercase(),
                                color = Color(0xFFBA1A1A),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column {
                            Text(
                                text = video.title,
                                color = cardTextColor,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "YouTube Video",
                                color = cardTextColor.copy(alpha = 0.6f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// SEARCH MODULE WITH LOCAL SEARCH AND MANUAL URL PARSER
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun SearchContent(
    viewModel: TVViewModel,
    onVideoSelected: (String, String) -> Unit,
    onNavigateToWeb: (String) -> Unit,
    isDark: Boolean
) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    var manualUrl by remember { mutableStateOf("") }
    var urlError by remember { mutableStateOf(false) }

    val allVideos = viewModel.allVideos
    val filteredVideos = if (searchQuery.isBlank()) {
        allVideos
    } else {
        allVideos.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                    it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Text(
                text = "Search Videos / वीडियो खोजें",
                color = if (isDark) Color.White else Color(0xFF1D1B20),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Search text input & Manual URL Loader
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Main Search Input
                TextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search title, category... / खोजें...") },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = if (isDark) Color(0xFF323035) else Color(0xFFE8DEF8),
                        unfocusedContainerColor = if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7),
                        focusedTextColor = if (isDark) Color.White else Color(0xFF1D1B20),
                        unfocusedTextColor = if (isDark) Color.White else Color(0xFF1D1B20)
                    )
                )

                // Manual URL Parser Input
                TextField(
                    value = manualUrl,
                    onValueChange = {
                        manualUrl = it
                        urlError = false
                    },
                    placeholder = { Text("Enter YouTube URL / लिंक दर्ज करें") },
                    modifier = Modifier.weight(1f),
                    isError = urlError,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = if (isDark) Color(0xFF323035) else Color(0xFFE8DEF8),
                        unfocusedContainerColor = if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7),
                        focusedTextColor = if (isDark) Color.White else Color(0xFF1D1B20),
                        unfocusedTextColor = if (isDark) Color.White else Color(0xFF1D1B20)
                    )
                )

                // Safe URL extractor Play Button
                Button(
                    onClick = {
                        val extractedId = viewModel.extractVideoId(manualUrl)
                        if (extractedId != null) {
                            urlError = false
                            onVideoSelected(extractedId, "Custom Web Video")
                        } else {
                            urlError = true
                        }
                    },
                    colors = ButtonDefaults.colors(
                        containerColor = Color(0xFFBA1A1A),
                        contentColor = Color.White
                    )
                ) {
                    Text("PLAY / चलाएं")
                }
            }
        }

        item {
            Button(
                onClick = {
                    val query = searchQuery.trim()
                    val targetUrl = if (query.isNotEmpty()) {
                        "https://m.youtube.com/results?search_query=${java.net.URLEncoder.encode(query, "UTF-8")}"
                    } else {
                        "https://m.youtube.com"
                    }
                    onNavigateToWeb(targetUrl)
                },
                colors = ButtonDefaults.colors(
                    containerColor = Color(0xFF6750A4),
                    contentColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "Search entire YouTube Web for \"$searchQuery\" / ऑनलाइन यूट्यूब खोजें" else "Explore entire YouTube Web / यूट्यूब ऑनलाइन ब्राउज़ करें",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }

        if (urlError) {
            item {
                Text(
                    text = "⚠️ Invalid YouTube URL. Enter standard format (e.g., https://youtu.be/abc)",
                    color = Color(0xFFBA1A1A),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Search Results List
        item {
            Text(
                text = "Search Results / परिणाम",
                color = if (isDark) Color.White else Color(0xFF1D1B20),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (filteredVideos.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No videos match your query.",
                        color = if (isDark) Color(0xFFCAC4D0) else Color(0xFF49454F),
                        fontSize = 16.sp
                    )
                }
            }
        } else {
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.focusGroup()
                ) {
                    items(filteredVideos) { video ->
                        var isFocused by remember { mutableStateOf(false) }

                        val borderModifier = if (isFocused) {
                            Modifier.border(3.dp, Color(0xFFBA1A1A), RoundedCornerShape(16.dp))
                        } else {
                            Modifier
                        }

                        Card(
                            onClick = { onVideoSelected(video.id, video.title) },
                            modifier = Modifier
                                .width(200.dp)
                                .height(130.dp)
                                .onFocusChanged { isFocused = it.isFocused }
                                .then(borderModifier)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(if (isDark) Color(0xFF323035) else Color(0xFFEADDFF))
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = video.title,
                                    color = if (isDark) Color.White else Color(0xFF1D1B20),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// FAVORITES SCREEN MODULE
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun FavoritesContent(
    favorites: List<FavoriteVideo>,
    onVideoSelected: (String, String) -> Unit,
    isDark: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
        Text(
            text = "My Saved Favorites / पसंदीदा वीडियो",
            color = if (isDark) Color.White else Color(0xFF1D1B20),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        if (favorites.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = "Empty",
                        tint = if (isDark) Color(0xFFCAC4D0) else Color(0xFF49454F),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Your favorite shelf is empty! Add videos to access them instantly.",
                        color = if (isDark) Color(0xFFCAC4D0) else Color(0xFF49454F),
                        fontSize = 16.sp
                    )
                }
            }
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.focusGroup()
            ) {
                items(favorites) { favorite ->
                    var isFocused by remember { mutableStateOf(false) }

                    val borderModifier = if (isFocused) {
                        Modifier.border(3.dp, Color(0xFFBA1A1A), RoundedCornerShape(16.dp))
                    } else {
                        Modifier
                    }

                    Card(
                        onClick = { onVideoSelected(favorite.videoId, favorite.title) },
                        modifier = Modifier
                            .width(200.dp)
                            .height(130.dp)
                            .onFocusChanged { isFocused = it.isFocused }
                            .then(borderModifier)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(if (isDark) Color(0xFF323035) else Color(0xFFEADDFF))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = favorite.title,
                                color = if (isDark) Color.White else Color(0xFF1D1B20),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

// APP CONFIGURATION / SETTINGS MODULE WITH AUTOPLAY & PIN CONTROLS
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun SettingsContent(
    viewModel: TVViewModel,
    settings: AppSettings,
    isDark: Boolean
) {
    var customPin by remember { mutableStateOf("") }
    val textColor = if (isDark) Color.White else Color(0xFF1D1B20)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(28.dp)
    ) {
        item {
            Text(
                text = "App Settings / सेटिंग्स",
                color = textColor,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Feature 1: Theme Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Dark Mode Theme / डार्क मोड", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Toggle visual styles for dynamic comfort", color = textColor.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Switch(
                    checked = settings.isDarkTheme,
                    onCheckedChange = { viewModel.updateTheme(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFBA1A1A),
                        checkedTrackColor = Color(0xFF6750A4)
                    )
                )
            }
        }

        // Feature 2: Autoplay Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Autoplay Videos / स्वतः चालू करें", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Start next video automatically", color = textColor.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Switch(
                    checked = settings.isAutoplayEnabled,
                    onCheckedChange = { viewModel.updateAutoplay(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFBA1A1A),
                        checkedTrackColor = Color(0xFF6750A4)
                    )
                )
            }
        }

        // Feature 3: Set Parental Lock Pin
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Configure Parental PIN / पेरेंटल लॉक", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("Lock access to Settings and Favorites screens to ensure safe TV browsing.", color = textColor.copy(alpha = 0.7f), fontSize = 12.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = customPin,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) customPin = it },
                        placeholder = { Text("Enter 4-Digit PIN") },
                        modifier = Modifier.width(200.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = if (isDark) Color(0xFF323035) else Color(0xFFE8DEF8)
                        )
                    )

                    Button(
                        onClick = {
                            viewModel.setParentalPin(customPin)
                            customPin = ""
                        },
                        colors = ButtonDefaults.colors(
                            containerColor = Color(0xFFBA1A1A),
                            contentColor = Color.White
                        )
                    ) {
                        Text(if (settings.parentalPin.isEmpty()) "Enable Lock" else "Update PIN")
                    }

                    if (settings.parentalPin.isNotEmpty()) {
                        Button(
                            onClick = {
                                viewModel.setParentalPin("")
                                customPin = ""
                            },
                            colors = ButtonDefaults.colors(
                                containerColor = Color.Gray,
                                contentColor = Color.White
                            )
                        ) {
                            Text("Disable Lock")
                        }
                    }
                }
            }
        }

        // Feature 4: Clear Watch History
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Data Management / इतिहास मिटाएं", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Button(
                    onClick = { viewModel.clearHistory() },
                    colors = ButtonDefaults.colors(
                        containerColor = Color(0xFFBA1A1A).copy(alpha = 0.15f),
                        contentColor = Color(0xFFBA1A1A)
                    )
                ) {
                    Text("Clear Watch History / इतिहास साफ़ करें")
                }
            }
        }
    }
}

// PIN LOCK INPUT PAD OVERLAY
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun PinLockScreen(
    pinValue: String,
    onPinValueChange: (String) -> Unit,
    onVerify: () -> Unit,
    onCancel: () -> Unit,
    isError: Boolean,
    isDark: Boolean
) {
    val textColor = if (isDark) Color.White else Color(0xFF1D1B20)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) Color(0xFF1D1B20).copy(alpha = 0.95f) else Color(0xFFFEF7FF).copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.width(360.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Lock",
                tint = Color(0xFFBA1A1A),
                modifier = Modifier.size(64.dp)
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Screen is Locked / लॉक स्क्रीन",
                    color = textColor,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Please enter your 4-digit security PIN.",
                    color = textColor.copy(alpha = 0.7f),
                    fontSize = 14.sp
                )
            }

            // Hidden PIN Display
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val isActive = i < pinValue.length
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isActive) Color(0xFFBA1A1A) else (if (isDark) Color(0xFF323035) else Color(
                                    0xFFE6E1E5
                                ))
                            )
                    )
                }
            }

            if (isError) {
                Text(
                    text = "Incorrect PIN code. Try again.",
                    color = Color(0xFFBA1A1A),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Remote-friendly virtual dial pad keys
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.focusGroup()
            ) {
                listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("Clear", "0", "Back")
                ).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { digit ->
                            var isKeyFocused by remember { mutableStateOf(false) }
                            val keyBg = if (isKeyFocused) Color(0xFFBA1A1A) else (if (isDark) Color(0xFF323035) else Color(0xFFEADDFF))
                            val keyText = if (isKeyFocused) Color.White else textColor

                            Box(
                                modifier = Modifier
                                    .size(60.dp, 44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(keyBg)
                                    .onFocusChanged { isKeyFocused = it.isFocused }
                                    .focusable()
                                    .onFocusChanged {
                                        // Empty focus binder
                                    }
                                    .focusable()
                                    .clickable {
                                        when (digit) {
                                            "Clear" -> onPinValueChange("")
                                            "Back" -> onCancel()
                                            else -> {
                                                if (pinValue.length < 4) {
                                                    val newVal = pinValue + digit
                                                    onPinValueChange(newVal)
                                                    if (newVal.length == 4) {
                                                        // Automatically trigger verification on fourth digit
                                                    }
                                                }
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = digit,
                                    color = keyText,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(
                    onClick = onVerify,
                    colors = ButtonDefaults.colors(
                        containerColor = Color(0xFFBA1A1A),
                        contentColor = Color.White
                    )
                ) {
                    Text("Unlock")
                }
                Button(
                    onClick = onCancel,
                    colors = ButtonDefaults.colors(
                        containerColor = Color.Gray,
                        contentColor = Color.White
                    )
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}

// ABOUT & LEGAL DISCLOSURES COMPLIANCE PAGE
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun AboutContent(isDark: Boolean) {
    val textColor = if (isDark) Color.White else Color(0xFF1D1B20)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Text(
                text = "Legal Compliance & About / नियम एवं शर्तें",
                color = textColor,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                onClick = {},
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.colors(
                    containerColor = if (isDark) Color(0xFF323035) else Color(0xFFEADDFF)
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Disclaimer & Attribution",
                        color = Color(0xFFBA1A1A),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "1. This app is completely independent and is not affiliated, associated, authorized, endorsed by, or in any way officially connected with YouTube, Google LLC, or any of their subsidiaries.\n\n" +
                                "2. This application plays publicly available videos in a secure, legal, and compliant manner using the official embeddable YouTube HTML5 Player within Android System WebView.\n\n" +
                                "3. The application does not download, copy, extract audio, or scrape any background content, and respects all YouTube monetization systems, ads, and Terms of Service.",
                        color = textColor,
                        fontSize = 14.sp,
                        lineHeight = 22.sp
                    )

                    HorizontalDivider(color = textColor.copy(alpha = 0.2f))

                    Text(
                        text = "Privacy Note",
                        color = Color(0xFFBA1A1A),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "All user preference settings, search logs, recently watched histories, and custom bookmarks are stored completely offline within your local Android TV internal storage database. No telemetry, metadata, or tracking information is transmitted to external servers.",
                        color = textColor,
                        fontSize = 14.sp,
                        lineHeight = 22.sp
                    )
                }
            }
        }
    }
}
