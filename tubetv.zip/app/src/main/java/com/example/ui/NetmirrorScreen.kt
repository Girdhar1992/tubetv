package com.example.ui

import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material3.ButtonDefaults as M3ButtonDefaults
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.tv.material3.*

data class NetmirrorDomain(
    val name: String,
    val url: String,
    val description: String
)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun NetmirrorScreen(
    isDark: Boolean,
    onBackToHome: () -> Unit
) {
    val domains = remember {
        listOf(
            NetmirrorDomain("Netmirror App", "https://netmirror.app", "Primary streaming mirror with latest series & movies"),
            NetmirrorDomain("Netmirror Site", "https://netmirror.site", "Alternative backup mirror for web series"),
            NetmirrorDomain("Netmirror HD", "https://netmirrorhd.app", "High-definition streaming server portal"),
            NetmirrorDomain("Netmirror Biz", "https://netmirrorapp.biz", "Alternative high-speed server portal")
        )
    }

    var selectedDomainUrl by remember { mutableStateOf<String?>(null) }
    var customUrlInput by remember { mutableStateOf("") }
    var activeUrlToLoad by remember { mutableStateOf<String?>(null) }

    val textColor = if (isDark) Color.White else Color(0xFF1D1B20)
    val cardBg = if (isDark) Color(0xFF323035) else Color(0xFFEADDFF)

    if (activeUrlToLoad != null) {
        // WebView active streaming container
        Box(modifier = Modifier.fillMaxSize()) {
            var webViewInstance by remember { mutableStateOf<WebView?>(null) }

            // Dynamic back key navigation for the WebView
            BackHandler(enabled = true) {
                val webView = webViewInstance
                if (webView != null && webView.canGoBack()) {
                    webView.goBack()
                } else {
                    activeUrlToLoad = null // Return to mirror dashboard
                }
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // TV navigation control bar above active WebView stream
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { activeUrlToLoad = null },
                        colors = ButtonDefaults.colors(
                            containerColor = Color(0xFFBA1A1A),
                            contentColor = Color.White
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Back to Mirrors / मिरर सूची", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Playing from: $activeUrlToLoad",
                        color = textColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )

                    Button(
                        onClick = {
                            webViewInstance?.reload()
                        },
                        colors = ButtonDefaults.colors(
                            containerColor = if (isDark) Color(0xFF323035) else Color(0xFFEADDFF),
                            contentColor = textColor
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reload",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reload / फिर से लोड करें", fontSize = 11.sp)
                        }
                    }
                }

                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    factory = { context ->
                        WebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                // High quality TV compatible User Agent for streaming portals
                                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                            }
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                    return false // Play everything inline inside the TV app webview
                                }
                            }
                            webChromeClient = WebChromeClient()
                            loadUrl(activeUrlToLoad!!)
                            webViewInstance = this
                        }
                    },
                    update = {
                        // Keep current loaded url
                    }
                )
            }
        }
    } else {
        // Mirrored domains listing and configuration
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Netmirror Series & Movies / फिल्में व वेब सीरीज",
                            color = textColor,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Watch Netflix, Prime Video and premium series mirrors directly / सीधे प्रीमियम वेब सिरीज़ और फ़िल्में चलाएं",
                            color = textColor.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0xFFBA1A1A), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "PREMIUM TV STREAM",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Quick instruction guide card
            item {
                Card(
                    onClick = {},
                    colors = CardDefaults.colors(
                        containerColor = if (isDark) Color(0xFF232126) else Color(0xFFF3EDF7)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "💡 Streaming Instructions & Help / निर्देश एवं सहायता",
                            color = Color(0xFFBA1A1A),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• Click on any server mirror card below to open Netmirror streaming directly on your TV.\n" +
                                    "• If one mirror is slow or blocked, try using Mirror 2, Mirror 3, or type a custom address.\n" +
                                    "• Use your TV remote's center button (D-Pad) to select series/episodes and control playback.\n" +
                                    "• Press the 'Back' key on your remote anytime to return to previous pages or this mirror list.",
                            color = textColor.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Selectable Mirror cards list
            item {
                Text(
                    text = "Select Server Mirror / सर्वर मिरर चुनें:",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Column(
                    modifier = Modifier.focusGroup(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    domains.forEach { domain ->
                        var isFocused by remember { mutableStateOf(false) }
                        val borderModifier = if (isFocused) {
                            Modifier.border(3.dp, Color(0xFFBA1A1A), RoundedCornerShape(16.dp))
                        } else {
                            Modifier
                        }

                        Card(
                            onClick = { activeUrlToLoad = domain.url },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .onFocusChanged { isFocused = it.isFocused }
                                .then(borderModifier),
                            colors = CardDefaults.colors(
                                containerColor = cardBg
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 20.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFFBA1A1A).copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Movie Stream",
                                            tint = Color(0xFFBA1A1A),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(
                                            text = domain.name,
                                            color = if (isFocused && !isDark) Color(0xFF1D1B20) else textColor,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = domain.description,
                                            color = if (isFocused && !isDark) Color(0xFF49454F) else textColor.copy(alpha = 0.65f),
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFBA1A1A), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "STREAM / चलाएं",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Custom URL configuration card
            item {
                Text(
                    text = "Load Custom Server Mirror / अन्य कस्टम लिंक चलाएं:",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = customUrlInput,
                        onValueChange = { customUrlInput = it },
                        placeholder = { Text("https://example-mirror.com") },
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = if (isDark) Color(0xFF323035) else Color(0xFFE8DEF8),
                            unfocusedContainerColor = if (isDark) Color(0xFF161519) else Color(0xFFF3EDF7),
                            focusedTextColor = textColor,
                            unfocusedTextColor = textColor
                        )
                    )

                    Button(
                        onClick = {
                            val cleanUrl = customUrlInput.trim()
                            if (cleanUrl.isNotEmpty()) {
                                val urlWithProtocol = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                                    "https://$cleanUrl"
                                } else {
                                    cleanUrl
                                }
                                activeUrlToLoad = urlWithProtocol
                            }
                        },
                        colors = ButtonDefaults.colors(
                            containerColor = Color(0xFFBA1A1A),
                            contentColor = Color.White
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Go",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("GO / चलाएं", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
