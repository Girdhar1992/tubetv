@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme
import androidx.tv.material3.lightColorScheme

private val DarkColorScheme =
  darkColorScheme(
      primary = PurplePrimary,
      secondary = RedSecondary,
      tertiary = LavenderTertiary,
      background = OnBackgroundDark,
      surface = OnBackgroundDark
  )

private val LightColorScheme =
  lightColorScheme(
      primary = PurplePrimary,
      secondary = RedSecondary,
      tertiary = LavenderTertiary,
      background = BackgroundLight,
      surface = BackgroundLight
  )

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
