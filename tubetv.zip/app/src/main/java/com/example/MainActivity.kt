package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.tv.material3.MaterialTheme
import com.example.ui.HomeScreen
import com.example.ui.YouTubePlayer
import com.example.ui.YouTubeWebView
import com.example.ui.TVViewModel
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.tv.material3.Text
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder

@OptIn(ExperimentalTvMaterial3Api::class)
class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel: TVViewModel = viewModel()
        val navController = rememberNavController()
        NavHost(navController = navController, startDestination = "home") {
          composable("home") {
            HomeScreen(
              viewModel = viewModel,
              onVideoSelected = { videoId, title ->
                viewModel.addToRecents(videoId, title)
                navController.navigate("player/$videoId")
              },
              onNavigateToWeb = { url ->
                val encodedUrl = java.net.URLEncoder.encode(url, "UTF-8")
                navController.navigate("web_browse/$encodedUrl")
              }
            )
          }
          composable("web_browse/{encodedUrl}") { backStackEntry ->
            val encodedUrl = backStackEntry.arguments?.getString("encodedUrl") ?: ""
            val decodedUrl = java.net.URLDecoder.decode(encodedUrl, "UTF-8")

            Box(modifier = Modifier.fillMaxSize()) {
              YouTubeWebView(
                initialUrl = decodedUrl,
                modifier = Modifier.fillMaxSize(),
                onExit = {
                  navController.popBackStack()
                }
              )
            }
          }
          composable("player/{videoId}") { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId") ?: ""
            val currentVideo = viewModel.allVideos.find { it.id == videoId }
            val videoTitle = currentVideo?.title ?: "Web Video"

            Box(modifier = Modifier.fillMaxSize()) {
              YouTubePlayer(videoId = videoId, modifier = Modifier.fillMaxSize())

              // Remote-friendly HUD Overlay Panel
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .align(Alignment.TopCenter)
                  .padding(24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Button(
                  onClick = { navController.popBackStack() },
                  colors = ButtonDefaults.colors(
                    containerColor = Color.Black.copy(alpha = 0.7f),
                    contentColor = Color.White
                  )
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.ArrowBack,
                      contentDescription = "Back",
                      tint = Color.White,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Back / वापस", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                  }
                }

                Box(
                  modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                  Text(
                    text = videoTitle,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 300.dp)
                  )
                }

                val favorites by viewModel.favorites.collectAsStateWithLifecycle()
                val isFav = favorites.any { it.videoId == videoId }

                Button(
                  onClick = {
                    if (currentVideo != null) {
                      viewModel.toggleFavorite(com.example.ui.VideoItem(currentVideo.id, currentVideo.title, currentVideo.category))
                    } else {
                      viewModel.toggleFavorite(com.example.ui.VideoItem(videoId, videoTitle, "Custom"))
                    }
                  },
                  colors = ButtonDefaults.colors(
                    containerColor = if (isFav) Color(0xFFBA1A1A).copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.7f),
                    contentColor = Color.White
                  )
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                      contentDescription = "Favorite",
                      tint = Color.White,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isFav) "Liked" else "Like / पसंद", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
